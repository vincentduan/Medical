/**
 * 
 */
package com.childraise.medical.sys.service;

import org.springframework.stereotype.Service;

/**
 * @author Jason_zh
 * @date 2016��6��2��
 * @version 1.0
 */
@Service("doctorService")
public class DoctorService {

}
