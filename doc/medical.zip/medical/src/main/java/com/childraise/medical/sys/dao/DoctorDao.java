/**
 * 
 */
package com.childraise.medical.sys.dao;

import org.springframework.stereotype.Repository;

/**
 * @author Jason_zh
 * @date 2016��6��2��
 * @version 1.0
 */
@Repository
public interface DoctorDao {

}
