package com.childraise.medical.sys.model;

/**
 * @author Jason_zh
 * @date 2016��6��2��
 * @version 1.0
 */
public class Doctor {

}
